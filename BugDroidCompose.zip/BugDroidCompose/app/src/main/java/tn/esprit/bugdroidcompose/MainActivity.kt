package tn.esprit.bugdroidcompose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import tn.esprit.bugdroidcompose.ui.theme.BugDroidComposeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BugDroidComposeTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    BugDroidLogo(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun BugDroidLogo(modifier: Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painter = painterResource(id = R.drawable.head), contentDescription = "Head Image")
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.hand), contentDescription = "Left Hand Image", contentScale = ContentScale.Fit
            )
            Image(
                painter = painterResource(id = R.drawable.body), contentDescription = "Body Image", modifier = Modifier.padding(horizontal = 5.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.hand), contentDescription = "Right Hand Image"
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Image(
                painter = painterResource(id = R.drawable.leg),
                contentDescription = "Left Leg Image",
                modifier = Modifier.padding(end = 5.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.leg), contentDescription = "Right Leg Image"
            )
        }
    }
}

@Preview(showBackground = true, device = "id:pixel")
@Composable
fun BugDroidPreview() {
    BugDroidComposeTheme {
        BugDroidLogo(Modifier.fillMaxSize())
    }
}